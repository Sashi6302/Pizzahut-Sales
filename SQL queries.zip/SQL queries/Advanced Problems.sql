-- Advanced:

-- Calculate the percentage contribution of each pizza type to total revenue.

-- Actual Code
SELECT 
    category,
    ROUND(SUM((price * quantity) * 100 / (SELECT 
                    ROUND(SUM(price * quantity), 2)
                FROM
                    order_details
                        JOIN
                    pizzas ON pizzas.pizza_id = order_details.pizza_id)),
            2) AS revenue
FROM
    pizza_types
        JOIN
    pizzas ON pizza_types.pizza_type_id = pizzas.pizza_type_id
        JOIN
    order_details ON order_details.pizza_id = pizzas.pizza_id
GROUP BY category
ORDER BY revenue DESC; 

-- Practice Code

select sum(revenue) from
(select category, round(sum(price*quantity),3) as revenue 
from pizza_types
join pizzas
on pizza_types.pizza_type_id = pizzas.pizza_type_id
join order_details
on order_details.pizza_id = pizzas.pizza_id
group by category
order by revenue desc) as revenue_table; 

select round(sum(price*quantity),2) 
from order_details 
join pizzas
on pizzas.pizza_id = order_details.pizza_id;

-- Analyze the cumulative revenue generated over time.

select order_date, 
round(sum(revenue) over(order by order_date),2) as cum_revenue
from
(select order_date , round(sum(price*quantity),2) as revenue
from orders
join order_details
on orders.order_id = order_details.order_id
join pizzas
on pizzas.pizza_id = order_details.pizza_id
group by order_date) as sales;


-- Determine the top 3 most ordered pizza types based on revenue for each pizza category.

-- Practice Code

select distinct name,category,round(sum(price*quantity) over(partition by name),2) as revenue
from pizza_types
join pizzas
on pizza_types.pizza_type_id = pizzas.pizza_type_id
join order_details
on order_details.pizza_id = pizzas.pizza_id;

-- Actual Code
-- Rank cannot be directly used in the where clause so we again used sub-query

select category,name,revenue
from
(select category, name,revenue,
rank() over(partition by category order by revenue desc) as rn
from
(select name,category,round(sum(price*quantity),2) as revenue
from pizza_types
join pizzas
on pizza_types.pizza_type_id = pizzas.pizza_type_id
join order_details
on order_details.pizza_id = pizzas.pizza_id
group by name, category) as a) as b
where rn<=3;
