-- Basics

-- Retrieve the total number of orders placed.

select count(order_id) from orders; 

-- Calculate the total revenue generated from pizza sales.
select order_details_id,sum(price*quantity) as total_price 
from pizzas
inner join order_details
on pizzas.pizza_id = order_details.pizza_id
group by order_details_id;

select round(sum(price*quantity),2) as total_revenue 
from pizzas
inner join order_details
on pizzas.pizza_id = order_details.pizza_id;

-- Identify the highest-priced pizza.
select pizza_types.name,price 
from pizzas
join pizza_types
on pizzas.pizza_type_id = pizza_types.pizza_type_id
where price in (
	select max(price) from pizzas
);

select pizza_types.name, pizzas.price
from pizzas
join pizza_types
on pizzas.pizza_type_id = pizza_types.pizza_type_id
order by pizzas.price desc
limit 1;

select max(price) from pizzas;

-- Identify the most common pizza size ordered.
select pizzas.size, count(pizzas.size) as Count
from pizzas
group by pizzas.size
order by Count desc Limit 1;

select size, count(order_details_id) as order_count
from pizzas
join order_details
on pizzas.pizza_id = order_details.pizza_id
group by size
order by order_count desc Limit 1;

-- List the top 5 most ordered pizza types along with their quantities.

select *
from pizzas
join order_details
on pizzas.pizza_id= order_details.pizza_id;

select pizza_type_id,count(order_details_id) as Count
from pizzas
join order_details
on pizzas.pizza_id= order_details.pizza_id
group by pizza_type_id
order by count desc limit 5;

-- We have to take 3 joins to solve this problem.

select name, sum(quantity) as quantity
from pizzas
join order_details
on pizzas.pizza_id= order_details.pizza_id
join pizza_types
on pizza_types.pizza_type_id = pizzas.pizza_type_id
group by name
order by quantity desc limit 5;